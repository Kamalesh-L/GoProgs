# Running the program confirms that the file is closed
# after being written.
$ go run defer.go
creating
writing
closing
