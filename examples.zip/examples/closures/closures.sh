$ go run closures.go
1
2
3
1

# The last feature of functions we'll look at for now is
# recursion.
