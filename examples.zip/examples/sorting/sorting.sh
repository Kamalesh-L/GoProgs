$ go run sorting.go
Strings: [a b c]
Ints:    [2 4 7]
Sorted:  true
