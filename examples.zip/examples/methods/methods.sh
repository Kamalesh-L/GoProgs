$ go run methods.go 
area:  50
perim: 30
area:  50
perim: 30

# Next we'll look at Go's mechanism for grouping and
# naming related sets of methods: interfaces.
