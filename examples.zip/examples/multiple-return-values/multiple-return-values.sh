$ go run multiple-return-values.go
3
7
7

# Accepting a variable number of arguments is another nice
# feature of Go functions; we'll look at this next.
