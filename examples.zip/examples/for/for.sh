$ go run for.go
1
2
3
0
1
2
range 0
range 1
range 2
loop
1
3
5

# We'll see some other `for` forms later when we look at
# `range` statements, channels, and other data
# structures.
