# Running this program shows the first operation timing
# out and the second succeeding.
$ go run timeouts.go 
timeout 1
result 2
