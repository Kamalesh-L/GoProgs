# Some of the generated numbers may be
# different when you run the sample.
$ go run random-numbers.go
68,56
0.8090228139659177
5.840125017402497,6.937056298890035
94,49
94,49

# See the [`math/rand/v2`](https://pkg.go.dev/math/rand/v2)
# package docs for references on other random quantities
# that Go can provide.
