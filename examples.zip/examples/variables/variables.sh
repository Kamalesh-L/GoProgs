$ go run variables.go
initial
1 2
true
0
apple
