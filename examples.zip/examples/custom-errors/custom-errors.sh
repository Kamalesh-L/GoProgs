$ go run custom-errors.go
42
can't work with it
