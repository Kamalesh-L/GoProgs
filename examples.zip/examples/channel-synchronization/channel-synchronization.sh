$ go run channel-synchronization.go      
working...done                  

# If you removed the `<- done` line from this program, the
# program would exit before the `worker` even
# started.
